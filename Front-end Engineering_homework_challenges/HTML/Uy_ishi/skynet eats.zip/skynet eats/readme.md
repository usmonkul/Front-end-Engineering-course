 # Skynet Eats — A11y/Front-end Bug Hunt (Talabalar uchun)
 
 Bu repoda ataylab qoldirilgan bir nechta **accessibility (a11y)**, **semantika**, va **UX** muammolari bor. Maqsad: muammolarni topish, sababi va yechimini tushunish, keyin tuzatish.
 
 ## Qanday ishlaysiz
 - **[Tekshirish]** Klaviatura bilan saytni aylanib chiqing: `Tab`, `Shift+Tab`, `Enter`, `Space`.
 - **[Tekshirish]** Lighthouse / Accessibility audit (Chrome DevTools) ishlating.
 - **[Tekshirish]** Ekran o‘quvchi (VoiceOver) bilan formalarni sinab ko‘ring.
 
 ## Topilishi kerak bo‘lgan muammolar (checklist)
 
 ### 1) HTML semantika va strukturasi
 - **[DOCTYPE yo‘q]** `index.html` va `signup.html` fayllarida `<!DOCTYPE html>` yo‘q.
 - **[Landmark’lar ishlatilmagan]** Navbar va footer oddiy `div` lar bilan qilingan.
   - Kutiladi: `header`, `nav`, `main`, `footer` va mantiqiy struktur.
 - **[Skip link yo‘q]** Klaviatura foydalanuvchilari uchun “Skip to main content” havolasi yo‘q.
 - **[Heading iyerarxiyasi]** `index.html` ichida bir nechta `h1` ishlatilgan (`Skynet Eats` va `Food Delivery Service`).
   - Kutiladi: bitta `h1`, keyin bo‘limlar `h2/h3`.
 
 ### 2) Linklar va navigatsiya
 - **[`href="#"` ishlatilgan]** Bir nechta linklar `href="#"` bilan turibdi (Home/About/Order Now va boshqalar).
   - Muammo: fokus/scroll “tepa”ga sakrashi, noaniq navigatsiya.
   - Kutiladi: real URL yoki `button` bo‘lishi kerak bo‘lsa `button`.
 - **[“Contact”/“Sign up” mantiqi]** Navigatsiyadagi matnlar va yo‘nalishlar chalkash (masalan `signup.html` “Contact” deb turibdi).
 
 ### 3) Rasmlar va ikonlar (alt/accessible name)
 - **[Rasmlarda `alt` yo‘q]** `index.html`:
   - `.hero-image` (`images/hero-image.jpg`) `alt` siz.
   - `.info-image` (`images/pal9000.jpg`) `alt` siz.
 - **[Dekorativ ikonlar]** Iconify/ionicons ikonlari screen reader’da keraksiz o‘qilishi mumkin.
   - Kutiladi: dekorativ bo‘lsa `aria-hidden="true"`, ma’no beradigan bo‘lsa aniq “accessible name”.
 
 ### 4) Formalar (label, type, submit, validation)
 - **[Label yo‘q]** `index.html` va `signup.html` formalarida input’lar `placeholder` bilan “label” o‘rnini bosyapti.
   - Kutiladi: har bir input uchun `<label for="...">` + `id`.
 - **[Noto‘g‘ri `type`]** `signup.html` ichida Email input `type="text"`.
   - Kutiladi: `type="email"`.
 - **[`name` atributlari yo‘q]** Form elementlarida `name` yo‘q (serverga yuborish/validatsiya uchun muammo).
 - **[Form submit noto‘g‘ri]**
   - `index.html` da submit o‘rniga `div` (`.submit-button`) ishlatilgan va `onclick` bor.
   - `signup.html` da button `type="button"` — form submit bo‘lmaydi.
   - Kutiladi: haqiqiy `<button type="submit">` va klaviatura bilan ishlashi.
 - **[Radio group semantikasi]** `Do you have cats?` qismi `fieldset/legend` siz.
   - Kutiladi: `<fieldset>` + `<legend>`.
 - **[Autocomplete/required yo‘q]** Foydalanuvchi tajribasi va a11y uchun `autocomplete`, `required`, `aria-invalid`, xato matni kerak bo‘lishi mumkin.
 
 ### 5) Klaviatura va fokus (focus visible)
 - **[Fokus ko‘rinishi noaniq]** Link/button’lar uchun aniq `:focus` / `:focus-visible` stili yo‘q.
 - **[“Button” bo‘lib ko‘ringan element]** `div.submit-button` fokuslanmaydi va `Enter/Space` bilan ishlamaydi.
 
 ### 6) Rang kontrasti va o‘qilish
 - **[Kontrast tekshiruvi]** Kulrang matnlar (`#aaaaaa`, `#555555`) va yashil (`#007000`) ranglar fon bilan kontrast bo‘yicha tekshirilsin.
   - Eslatma: WCAG AA (oddiy matn uchun 4.5:1) ga yaqinlashish.
 
 ### 7) Responsive dizayn
 - **[Gorizontal scroll]** `body { min-width: 900px; }` va qat’iy `width` lar sabab kichik ekranda gorizontal scroll paydo bo‘ladi.
   - Kutiladi: `max-width`, `width: 100%`, media query.
 
 ### 8) Texnik/xatoliklar
 - **[Yo‘q CSS fayl]** `signup.html` `index.css` ni ulagan, lekin repo’da `index.css` yo‘q.
   - Kutiladi: to‘g‘ri fayl (`style.css`) yoki haqiqiy `index.css`.
 - **[Undefined JS]** `index.html` da `onclick="submitForm()"` bor, lekin `submitForm` funksiyasi repo’da topilmaydi.
 
 ## Bonus topshiriqlar
 - **[ARIA’ni minimal ishlating]** Avval semantik HTML bilan yeching, keyin kerak bo‘lsa ARIA qo‘shing.
 - **[Error messaging]** Form validatsiyasida xatolarni foydalanuvchiga (va screen reader’ga) tushunarli qilib ko‘rsating.
 - **[Tab order]** Fokus tartibi vizual tartibga mos kelishini tekshiring.
 
 ## Topshirish
 - **[Natija]** Har bir topilgan muammo uchun:
   - Qayerda (fayl + qator yoki bo‘lim)
   - Nima muammo
   - Nega a11y/UX ga zarar
   - Qanday tuzatdingiz (qisqa izoh)
