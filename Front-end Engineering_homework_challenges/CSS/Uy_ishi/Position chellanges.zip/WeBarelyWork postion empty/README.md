Colors

Text: whitesmoke,
#282828
#cd6858;
#dda15e;
#999;